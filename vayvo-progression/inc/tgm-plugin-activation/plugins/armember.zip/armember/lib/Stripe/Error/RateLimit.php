<?php

namespace Stripe\Error;

class RateLimit extends Stripe_InvalidRequest
{
}
