<html>
	<head></head>
	<body>
		<form action="upload.php" id="arm_iframe_form" method="post" enctype="multipart/form-data">
			<input type="file" id="armfileselect" name="armfileselect" class="original" style="position: absolute; cursor: pointer; top: 0px; width: 75px; height: 35px; left: 0px; z-index: 100; opacity: 0; filter:alpha(opacity=0);"/>
		</form>
	</body>
</html>